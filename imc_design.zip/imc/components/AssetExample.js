import * as React from 'react';
import { Text, View, StyleSheet, Image, TextInput, Button, Title } from 'react-native';

export default function AssetExample() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        Cálculo de IMC com Base em Altura e Peso
      </Text>
      
      <TextInput style={styles.textbox}
      placeholder="Digite sua Altura"/>
      
      <TextInput style={styles.textbox}
      placeholder="Digite seu Peso"/>

      <Button title="Calcular" color='#4169e1'/>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  textbox: {
    marginTop: 8,
    fontSize:15,
    marginBottom: 10,
    borderWidth: 1,
    padding: 3,
    backgroundColor: `#ffffff`
  },
  paragraph: {
    margin: 1,
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    color: `#f0f8ff`,
  },
});
